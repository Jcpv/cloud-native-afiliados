# cluod-native-afiliados2020

curl -X 'POST' \
  'localhost/cloud_native_proy/api.php/analisis/afiliados2020' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d ' {
    "id_ent": "4",
    "id_mun": "07091",
    "sex": "2",
    "gpo_edad": "10",
    "mun_frontera": "2",
    "afiliados": "p0",
    "personas": "2141"
}'